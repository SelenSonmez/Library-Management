ShipsGo Trainee Docs

---------------

## Installation for Developement

### Installation

#### WSL

Check if virtualization is turned on from BIOS.

#### Install Ubuntu 20.04 Distribution with WSL

```bash
wsl --install -d Ubuntu-20.04

```

#### Check WSL Version

Check the WSL version from Windows Powershell after Ubuntu installion. The version must be 2.

```bash
wsl --status

wsl -l -v

```

#### Install Php & Php Requirements

```bash
sudo su

apt update -y \
   && apt upgrade -y \
   && apt install software-properties-common zip unzip -y \
   && add-apt-repository ppa:ondrej/php -y \
   && apt update -y \
   && apt upgrade -y \
   && apt install php8.1-{common,cli,opcache,mysql,curl,mbstring,xml,bcmath,gd,redis,zip,intl} -y

```

#### Install Composer

```bash
sudo su 

php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');" \
    && php composer-setup.php \
    && php -r "unlink('composer-setup.php');" \
    && mv composer.phar /usr/local/bin/composer

```

#### Set Git Credentials (for WSL Ubuntu)

```bash
git config --global user.name "Your Name"

git config --global user.email "youremail@domain.com"

git config --global credential.helper store

```

### Requirements
- [Docker Desktop](https://www.docker.com/products/docker-desktop/) or docker enginge with compose plugin (on Windows WSL 2 setup recommended)
- [Git](https://git-scm.com/downloads) (installed on Ubuntu - WSL 2 by default)

### Recommendations
- [Visual Studio Code](https://code.visualstudio.com/download) - Code Editor aka VS Code
    - Ext: [Material Icon Theme](https://marketplace.visualstudio.com/items?itemName=PKief.material-icon-theme) - for better workspace look
    - Ext: [PHP Intelephense](https://marketplace.visualstudio.com/items?itemName=bmewburn.vscode-intelephense-client) - formatting and auto-complete for PHP classes/functions etc.
    - Ext: [Remote - WSL](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-wsl) - better terminal experience for WSL setup from VS Code
    - Ext: [DotENV](https://marketplace.visualstudio.com/items?itemName=mikestead.dotenv) - syntax highlighting for .env files
- [DBeaver](https://dbeaver.io/) - Universal Database Tool

### Useful Links

- [PSR Standarts](https://www.php-fig.org/)
- [Git Tutorial](https://git-scm.com/docs/gittutorial)

## Tasks

- [Php Basics](https://gitlab.com/shipsgo-training2/training-docs/-/blob/master/0001.md)
- [CURL Usages](https://gitlab.com/shipsgo-training2/training-docs/-/blob/master/0002.md)
- [OOP & Autoloader](https://gitlab.com/shipsgo-training2/training-docs/-/blob/master/0003.md)
- [Composer Usages](https://gitlab.com/shipsgo-training2/training-docs/-/blob/master/0004.md)
- [IMDB Tutorial](https://gitlab.com/shipsgo-training2/training-docs/-/blob/master/0005.md)
- [MySQL Examples with Composer Package](https://gitlab.com/shipsgo-training2/training-docs/-/blob/master/0006.md)
- [Laravel Tutorial and Projects](https://gitlab.com/shipsgo-training2/training-docs/-/blob/master/0007.md)